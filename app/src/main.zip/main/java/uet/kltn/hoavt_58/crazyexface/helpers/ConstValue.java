package uet.kltn.hoavt_58.crazyexface.helpers;

/**
 * Created by hoavt_58 on 4/9/17.
 */

public class ConstValue {

    public static final String EXTRA_FRAME_INDEX = "EXTRA_FRAME_INDEX";
    public static final String EXTRA_FACE_OBJECT = "EXTRA_FACE_OBJECT";
    public static final String EXTRA_CURRENT_SELECTED_RECT = "EXTRA_CURRENT_SELECTED_RECT";
    public static final long GALLERY_SHARED_ITEM_INTERVAL = 300;
    public static final String EXTRA_FACE_IDS = "EXTRA_FACE_IDS";
//    public static final String EXTRA_LIST_THUMBS = "EXTRA_LIST_THUMBS";
}
